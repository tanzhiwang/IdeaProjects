create view cid3 as
  select `yun6`.`tb_category`.`parent_id` AS `parent_id`
  from `yun6`.`tb_category`
  group by `yun6`.`tb_category`.`parent_id`;

